defmodule :"Elixir.Fitcrm.Repo.Migrations.Create Recipe Model" do
  use Ecto.Migration

  def change do

  end
end
