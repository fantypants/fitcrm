defmodule :"Elixir.Fitcrm.Repo.Migrations.Readding workout" do
  use Ecto.Migration

  def change do

  end
end
